<?php

include_once "RestController.php";

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode( '/', $uri );

if ($uri[2] !== 'cats') {
    header("HTTP/1.1 404 Not Found");
    exit();
}

$catId = null;
if (isset($uri[3])) {
    $catId = (int) $uri[3];
}

$requestMethod = $_SERVER["REQUEST_METHOD"];

$controller = new RestController($requestMethod, $catId);
$controller->processRequest();